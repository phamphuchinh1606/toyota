
        <div class="row">
            <div class="col s12 m5 l5">
                <h1 class="name_dt animated fadeInDownShort go">
                    <span id="spTitleCar">Corolla Altis 1.8E (MT)</span>
                </h1>
                <input type="hidden" id="hdCatId" value="821">
                <input type="hidden" id="hdCarId" value="1758">
                <p class="txt_dt animated fadeInLeftShort go">An toàn tối ưu,  <br>vận hành êm ái</p>
                <p class="price_dt animated fadeInUpShort go price_detail">697.000.000 <sup>VND</sup></p>
                <p class="txt_dt_2 animated fadeInUpShort go">
                    <span>• Số chỗ ngồi : 5 chỗ </span>
                    <br>
                    <span>• Kiểu dáng : Sedan </span>
                    <br>
                    <span>• Nhiên liệu : Xăng </span>
                    <br>
                    <span>• Xuất xứ : Xe trong nước </span>
                    <br>
                    <span>• Thông tin khác: <br>    + Số tay 6 cấp<br>   + Động cơ xăng dung tích 1.798 cm3 </span>
                </p>
                
                    
                        
                            
                        
                    
                    
                        
                            
                            
                        
                    
                

            </div>
            <div class="col l7 m7 s12">
                <div class="chk_color_box">
                    <div class="img_box">
                        <img class="lazy" data-original="<?php echo e(asset('images/guest/temp/xe_trang.png')); ?>" alt="Đen 218" src="<?php echo e(asset('images/guest/temp/xe_trang.png')); ?>" style="display: inline;">
                    </div>
                    <div class="list-color">
                        <ul>
                            <p class="txt-color">Trắng 040</p>
                            <li class=""><span data-img="/data/news/1758/_color/18e-black218_1506074874.png?width=600" data-cl="Đen 218" data-price="697.000.000 <sup>VND</sup>" style="background-color: #16160e"></span></li>
                            <li class=""><span data-img="/data/news/1758/_color/18e-brown-4w9_1506074924.png?width=600" data-cl="Nâu 4W9" data-price="697.000.000 <sup>VND</sup>" style="background-color: #624b47"></span></li>
                            <li class=""><span data-img="/data/news/1758/_color/18e-silver-1d4_1506074940.png?width=600" data-cl="Bạc 1D4" data-price="697.000.000 <sup>VND</sup>" style="background-color: #e0e0e0"></span></li>
                            <li class="active"><span data-img="/data/news/1758/_color/18e-while-040_1506074971.png?width=600" data-cl="Trắng 040" data-price="697.000.000 <sup>VND</sup>" style="background-color: #ffffff"></span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
