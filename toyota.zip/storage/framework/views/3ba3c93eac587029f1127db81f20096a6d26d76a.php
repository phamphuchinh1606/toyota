<?php $__env->startSection('body.js'); ?>
    <script src="<?php echo e(asset('js/guest/home.js')); ?>" type='text/javascript'></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    
    <?php echo $__env->make('guest.home.partials.__main_slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('guest.home.partials.__product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('guest.home.partials.__promotion_product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('guest.home.partials.__blog_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>