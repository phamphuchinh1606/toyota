<a href="tel:{{$appInfo->app_phone}}" class="suntory-alo-phone suntory-alo-green" id="suntory-alo-phoneIcon" style="left: 0px; bottom: 0px;">
    <div class="suntory-alo-ph-circle"></div>
    <div class="suntory-alo-ph-circle-fill"></div>
    <div class="suntory-alo-ph-img-circle">
        <img src="{{asset('images/guest/call.png')}}">
    </div>
</a>
